package com.swe645.sshres18;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Student entity manager  to interact with the database/file for CRUD. 
 * @author sshres18
 *
 */

public class StudentEntityManager {
	
	
	public static ArrayList<Student> getSearchResult(String fName,
	String lName,
	String city,
	String state) throws SQLException{
		
		List<Student> list = new ArrayList<Student>();
    	Connection con = null;
    	PreparedStatement ps = null;
    	ResultSet rs = null;
        try {
            Class.forName ("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException ex) {
           
        }
        try {
            con = DriverManager.getConnection (
                    "jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g",
                    "sshres18", "esoals");
        } catch (SQLException ex) {
            
        }
        
        
        String sql = "select * from Surveys s where lower(s.firstName) like '"+fName.toLowerCase()+"' or lower(s.lastName)='"+lName.toLowerCase()+
				 "' or lower(s.city)='"+city.toLowerCase()+"' or lower(s.state)='"+state.toLowerCase()+"'";
        ps= con.prepareStatement(sql); 
        rs= ps.executeQuery(); 
        while (rs.next())
        {
        Student st = new Student();
        st.setSurveyid(rs.getInt("SURVEYID"));
        st.setFirstName(rs.getString("FIRSTNAME"));
        st.setLastName(rs.getString("LASTNAME"));
        st.setEmail(rs.getString("EMAIL"));
        st.setUrl(rs.getString("URL"));
        st.setTelephoneNumber(rs.getString("TELEPHONENUMBER"));
        st.setStreetAddress(rs.getString("STREETADDRESS"));
        st.setCity(rs.getString("CITY"));
        st.setState(rs.getString("STATE"));
        st.setZip(rs.getString("ZIP"));
        st.setComments(rs.getString("COMMENTS"));
        String[] tokens = rs.getString("CLIKES").split(",", -1);
        st.setLikes(tokens);
        st.setInterests(rs.getString("INTERESTS"));
        st.setRecommendation(rs.getString("RECOMMENDATION"));
       // st.setDateOfSurvey(rs.getDate("DATEOFSURVEY"));
       // st.setDateOfStart(rs.getDate("DATEOFSTART"));
        list.add(st);
        } 
	return (ArrayList<Student>) list;	
	}
	
	public void deleteStudent(String sid) throws SQLException{
				
				Connection con = null;
		    	PreparedStatement ps = null;
		    	ResultSet rs = null;
		        try {
		            Class.forName ("oracle.jdbc.driver.OracleDriver");
		        } catch (ClassNotFoundException ex) {
		           
		        }
		        try {
		            con = DriverManager.getConnection (
		                    "jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g",
		                    "sshres18", "esoals");
		        } catch (SQLException ex) {
		            
		        }
		        
		        
		        String sql = "delete from Surveys where surveyid="+sid;
		        ps= con.prepareStatement(sql); 
		        rs= ps.executeQuery(); 
		        	
			}
	
}
