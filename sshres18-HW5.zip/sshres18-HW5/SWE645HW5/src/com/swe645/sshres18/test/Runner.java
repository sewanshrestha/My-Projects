package com.swe645.sshres18.test;

import com.swe645.sshres18.Student;
import com.swe645.sshres18.SurveyServiceImpl;

public class Runner {

	public static void main(String[] args) {
		System.out.println("Here");
		SurveyServiceImpl sim = new SurveyServiceImpl();
		System.out.println(sim.getSearchResult("Neha", "", "", ""));
		//Endpoint.publish("http://localhost:8080/SWE645HW5/surveySearch", new SurveyServiceImpl());
		Student s = new Student();
		s.setSurveyid(81);
		sim.deleteStudent(s);
	}

}
