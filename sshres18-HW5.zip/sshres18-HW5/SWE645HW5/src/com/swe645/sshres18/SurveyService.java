/**
Interface class as end point of then web service
*/
package com.swe645.sshres18;

import java.util.List;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@WebService
@SOAPBinding(style = Style.DOCUMENT)
public interface SurveyService {
	
	@WebMethod
	List<Student> getSearchResult(String fName, String lName, String city, String state);

	@WebMethod
	void deleteStudent(Student sid);
}
