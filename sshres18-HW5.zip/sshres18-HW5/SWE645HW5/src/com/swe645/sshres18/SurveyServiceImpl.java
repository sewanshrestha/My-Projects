/**
Webservice implementation for the search and delete methids
*/
package com.swe645.sshres18;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.sql.DataSource;

@WebService(
endpointInterface = "com.swe645.sshres18.SurveyService")
public class SurveyServiceImpl implements SurveyService{

	@Resource (name="jdbc/survey")
	DataSource dataSource;
	
	@WebMethod
	public List<Student> getSearchResult(@WebParam(name="fName") String fName, 
										 @WebParam(name="lName")String lName, 
										 @WebParam(name="city")String city, 
										 @WebParam(name="state")String state){
		List<Student> resultToReturn = new ArrayList<>();
		System.out.println(fName+"---"+lName+"---"+city+"---"+state);
		if(fName != null|| lName != null|| city != null || state != null){
			StudentEntityManager sem = new StudentEntityManager();
			try {
				resultToReturn = sem.getSearchResult(fName,lName,city,state);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//return "test";
		return resultToReturn;
	}
	@WebMethod
	public void deleteStudent(@WebParam(name="sid") Student s){
		String sid = s.getSurveyid()+"";
		if(sid != null){
			StudentEntityManager sem = new StudentEntityManager();
			try {
				 sem.deleteStudent(sid);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//return "test";
		//return resultToReturn;
	}
}
