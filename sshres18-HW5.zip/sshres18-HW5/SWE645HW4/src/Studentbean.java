//import java.sql.SQLException;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.validator.ValidatorException;
import javax.faces.*;

import org.primefaces.json.JSONException;
import org.primefaces.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.swe645.sshres18.SurveyService;
import com.swe645.sshres18.SurveyServiceImplService;

/**
 * Manager bean for the project which takes the requests from the JSFs and sends them to Service file to save,
 * calculate mean and standard deviation and get the list of surveys. The City and State are populated from the entered Zip code using web service. 
 * The options for recommendations are also made autocomplete
 * @author sshres18
 *
 */

@ManagedBean

public class Studentbean{
	
	private String searchName, searchSurname, searchCity, searchState;
	
	
	
	public String getSearchName() {
		return searchName;
	}

	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}

	public String getSearchSurname() {
		return searchSurname;
	}

	public void setSearchSurname(String searchSurname) {
		this.searchSurname = searchSurname;
	}

	public String getSearchCity() {
		return searchCity;
	}

	public void setSearchCity(String searchCity) {
		this.searchCity = searchCity;
	}

	public String getSearchState() {
		return searchState;
	}

	public void setSearchState(String searchState) {
		this.searchState = searchState;
	}

	private Student student = new Student();
	private WinningResult wr = new WinningResult();
	//private List<Student> students = new ArrayList<Student>();
	private String surveyList;
	
	public String getSurveyList(){
		return this.surveyList;
	}
	
	public void setSurveyLisy(String surveyList){
		this.surveyList = surveyList;
	}
	public WinningResult getWr() {
		return wr;
	}

	public void setWr(WinningResult wr) {
		this.wr = wr;
	}

	public Studentbean(){
		
	}
	
	public Student getStudent() {
		return student;
	}
    /*
	public void setStudent(Student student){
		this.student = student;
	}
	*/
	
	/* fordb
	public String processSave() throws ClassNotFoundException, SQLException{
		StudentService studentService = new StudentService();
	    String saveStatus = studentService.saveStudent(student);
		String calculation = studentService.calculateMean(student.getRaffle());
		
		String pro[] = calculation.split(" ");
        
        double avg = Double.parseDouble(pro[0]);
        double sd = Double.parseDouble(pro[1]);
        
        wr.setMean(avg);
        wr.setStandarddeviation(sd);
        
        if(avg > 90){
        	return "WinnerAcknowledgement";
        }
        
        return "SimpleAcknowledgement";
		
	}
	*/
	
	
	
	public String processSave() throws IOException{
		StudentService studentService = new StudentService();
		//String saveStatus = studentService.saveStudent(student);
		//studentService.writeFile(student);
		//System.out.println(""student.getDateOfStart());
		
		StudentEntityManager sem = new StudentEntityManager();
		sem.addSurvey(student);
		String calculation = studentService.calculateMean(student.getRaffle());
		
		String pro[] = calculation.split(" ");
	    
	    double avg = Double.parseDouble(pro[0]);
	    double sd = Double.parseDouble(pro[1]);
	    
	    wr.setMean(avg);
	    wr.setStandarddeviation(sd);
	    //students.add(student);
	    FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_result",this.studentSurveyWS);
		
	    if(avg > 90){
	    	return "winner";
	    }
	    
	    return "simple";
	    
	}
	
	public void datecheck(AjaxBehaviorEvent a) throws ValidatorException{
		FacesContext fc = FacesContext.getCurrentInstance();
		Date tempSurveyDate = (Date)student.getDateOfSurvey();
		Date tempStartDate  = (Date)student.getDateOfStart();
		System.out.println(tempSurveyDate+"--"+tempStartDate);
		if(tempStartDate.before(tempSurveyDate)){
			fc.addMessage(null, new FacesMessage("Start date is before the survey date!"));
		}
	}
	
	public void updateaddress() throws JSONException{
		FacesContext fc = FacesContext.getCurrentInstance();
		String tempZip = "";
		
	//	HelperClass hc = new HelperClass();
	//	String zipJson = hc.getAddressesForJSON();
		
		try{
			 tempZip = student.getZip();
		}
		catch(Exception e){
			fc.addMessage(null, new FacesMessage("Zipcode not digits!"));
		}
		Client client = Client.create();
		WebResource wrs = client.resource("http://ec2-52-87-171-144.compute-1.amazonaws.com/SWE645HW3/webresources/addresses/"+tempZip);
		ClientResponse resp = wrs.accept("application/json").get(ClientResponse.class);
		String tempZipjson = resp.getEntity(String.class);
		/*
		String tempAddress = aws.getStateInfo(tempZip);
		if(tempAddress.equals("")){
			fc.addMessage(null, new FacesMessage("Zipcode not found!"));
		}
		else{
			 String[] tempVal =  tempAddress.split("::", 2);
		     student.setCity(tempVal[0]);
		     student.setState(tempVal[1]);
		}
		*/
		
		JSONObject job = new JSONObject(tempZipjson);
		String tempState="", tempCity="";
		try{
			 tempState = job.getString("state");
			 tempCity  = job.getString("city");
		}
		catch(JSONException j){
			fc.addMessage(null, new FacesMessage("Zipcode not found!"));
		}
		if(tempState.equals("null") || tempCity.equals("null")){
			fc.addMessage(null, new FacesMessage("Zipcode not found!"));	
		}
		else{
			student.setCity(tempCity);
			student.setState(tempState);
		}
		
	}
	
	
	

	/*
	public List<Student> getStudentList() throws SQLException{
		StudentService studentService = new StudentService();
		return studentService.retrieve();
	}
	*/
	
	public List<Student> getSurveyListing(){
		List<Student> students = new ArrayList<Student>();
		StudentEntityManager sem = new StudentEntityManager();
		students = sem.getAllSurveys();
		//srv.readFile(students);
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_result",this.studentSurveyWS);
		
		return students;
		
	}
	
	private List<Student> studentSurvey = new ArrayList<Student>();
	private List<com.swe645.sshres18.Student> studentSurveyWS = new ArrayList<com.swe645.sshres18.Student>();

	public String processSearch(){
		System.out.println(searchName+"---"+searchSurname+"---"+searchCity+"---"+searchState);
		if(this.searchName != null|| this.searchSurname != null|| this.searchCity != null || this.searchState != null){
		/*
		StudentEntityManager sem = new StudentEntityManager();
		this.studentSurvey = sem.getSearchResult(searchName,searchSurname,searchCity,searchState);
		*/
			SurveyServiceImplService sem = new SurveyServiceImplService();
			SurveyService s = sem.getSurveyServiceImplPort();
			this.studentSurveyWS=  s.getSearchResult(searchName,searchSurname,searchCity,searchState);
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_result",this.studentSurveyWS);
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_firstname",this.searchName);
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_lastname",this.searchSurname);
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_city",this.searchCity);
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_state",this.searchState);
		
		}
		
		return null;
		
	}
	
	public List<com.swe645.sshres18.Student> getStudentSurveyWS() {
		return studentSurveyWS;
	}

	public void setStudentSurveyWS(List<com.swe645.sshres18.Student> studentSurveyWS) {
		this.studentSurveyWS = studentSurveyWS;
	}

	public String processDelete(com.swe645.sshres18.Student stud){
		//StudentEntityManager sem = new StudentEntityManager();
		//sem.deleteSurvey(stud);
		SurveyServiceImplService sem = new SurveyServiceImplService();
		sem.getSurveyServiceImplPort().deleteStudent(stud);
		//SurveyService s = sem.getSurveyServiceImplPort();
		//this.studentSurveyWS=  s.getSearchResult(searchName,searchSurname,searchCity,searchState);
		
		this.studentSurveyWS = sem.getSurveyServiceImplPort().getSearchResult(this.searchName,this.searchSurname,this.searchCity,this.searchState);
		
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_result",this.studentSurveyWS);
		/*
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_firstname",this.searchName);
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_lastname",this.searchSurname);
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_city",this.searchCity);
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("search_state",this.searchState);
		*/
		return "SearchPage";
		
	}
	
	public List<Student> getStudentSurvey(){
		return this.studentSurvey;
	}
	
	public void setStudentSurvey(List<Student> studentSurvey){
		this.studentSurvey = studentSurvey;
	}
	private static final String options = "Likely,Unlikely,Very Likely";
	private static final String[] toCheck = options.split(",");
	
	public List<String> recommendOption(String entry){
		List<String>matchFound = new ArrayList<String>();
		for(String value : toCheck){
			if(value.toLowerCase().startsWith(entry.toLowerCase())){
				matchFound.add(value);
			}
		}
		
		return matchFound;
	}
	
	public String sessionDestroy(){
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
		return null;
	}
/*
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	*/
}
