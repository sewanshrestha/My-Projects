/**
 * Winning data object(POJO) to store the individual attributes for mean and standard deviation
 * @author sshres18
 *
 */
public class WinningResult {
private double mean;
private double standarddeviation;

public WinningResult(){
	
}
public double getMean() {
	return mean;
}
public void setMean(double mean) {
	this.mean = mean;
}
public double getStandarddeviation() {
	return standarddeviation;
}
public void setStandarddeviation(double standarddeviation) {
	this.standarddeviation = standarddeviation;
}

}
