package com.sshres18.swe645;
/**
 * Class to create the City and State for the Restful services
 * @author sshres18
 *
 */
public class AddressInfo {
	String state, city;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	
}
