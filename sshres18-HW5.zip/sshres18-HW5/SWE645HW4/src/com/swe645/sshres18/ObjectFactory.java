
package com.swe645.sshres18;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.swe645.sshres18 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DeleteStudentResponse_QNAME = new QName("http://sshres18.swe645.com/", "deleteStudentResponse");
    private final static QName _GetSearchResultResponse_QNAME = new QName("http://sshres18.swe645.com/", "getSearchResultResponse");
    private final static QName _GetSearchResult_QNAME = new QName("http://sshres18.swe645.com/", "getSearchResult");
    private final static QName _DeleteStudent_QNAME = new QName("http://sshres18.swe645.com/", "deleteStudent");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.swe645.sshres18
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetSearchResultResponse }
     * 
     */
    public GetSearchResultResponse createGetSearchResultResponse() {
        return new GetSearchResultResponse();
    }

    /**
     * Create an instance of {@link DeleteStudentResponse }
     * 
     */
    public DeleteStudentResponse createDeleteStudentResponse() {
        return new DeleteStudentResponse();
    }

    /**
     * Create an instance of {@link DeleteStudent }
     * 
     */
    public DeleteStudent createDeleteStudent() {
        return new DeleteStudent();
    }

    /**
     * Create an instance of {@link GetSearchResult }
     * 
     */
    public GetSearchResult createGetSearchResult() {
        return new GetSearchResult();
    }

    /**
     * Create an instance of {@link Student }
     * 
     */
    public Student createStudent() {
        return new Student();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteStudentResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sshres18.swe645.com/", name = "deleteStudentResponse")
    public JAXBElement<DeleteStudentResponse> createDeleteStudentResponse(DeleteStudentResponse value) {
        return new JAXBElement<DeleteStudentResponse>(_DeleteStudentResponse_QNAME, DeleteStudentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSearchResultResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sshres18.swe645.com/", name = "getSearchResultResponse")
    public JAXBElement<GetSearchResultResponse> createGetSearchResultResponse(GetSearchResultResponse value) {
        return new JAXBElement<GetSearchResultResponse>(_GetSearchResultResponse_QNAME, GetSearchResultResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSearchResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sshres18.swe645.com/", name = "getSearchResult")
    public JAXBElement<GetSearchResult> createGetSearchResult(GetSearchResult value) {
        return new JAXBElement<GetSearchResult>(_GetSearchResult_QNAME, GetSearchResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteStudent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sshres18.swe645.com/", name = "deleteStudent")
    public JAXBElement<DeleteStudent> createDeleteStudent(DeleteStudent value) {
        return new JAXBElement<DeleteStudent>(_DeleteStudent_QNAME, DeleteStudent.class, null, value);
    }

}
