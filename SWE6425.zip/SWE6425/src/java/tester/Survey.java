/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tester;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author blaugrana
 */
public class Survey extends ActionSupport implements ModelDriven<StudentBean>{
    private StudentBean studentbean = new StudentBean();
    private StudentBean studentbeanNew = new StudentBean();
    private DataBean dtbn = new DataBean();
    private String datacalc = ""; 
    private StudentDAO sdao = new StudentDAO();
    private String StudentId = "";
    private String[] listreturn;
    
    public StudentBean getStudentbeanNew(){
        return studentbeanNew;
    }
    
    public void setStudentbeanNew(StudentBean studentbeannew){
        this.studentbeanNew = studentbeannew;
    }
    
    public String[] getListreturn() {
        return listreturn;
    }

    public void setListreturn(String[] listreturn) {
        this.listreturn = listreturn;
    }
    
    public String getStudentId() {
        return StudentId;
    }

    public void setStudentId(String StudentId) {
        this.StudentId = StudentId;
    }
    public StudentBean getStdbn() {
        return studentbean;
    }

    public void setStdbn(StudentBean studentbean) {
        this.studentbean = studentbean;
    }

    public DataBean getDtbn() {
        return dtbn;
    }

    public void setDtbn(DataBean dtbn) {
        this.dtbn = dtbn;
    }

    public StudentDAO getStdao() {
        return sdao;
    }

    public void setStdao(StudentDAO sdao) {
        this.sdao = sdao;
    }

    public String getDatacalc() {
        return datacalc;
    }

    public void setDatacalc(String datacalc) {
        this.datacalc = datacalc;
    }
    
    
    @Override
    public String execute(){ 
        String fwdlink="";
        try { 
            Connection con = null;
            
            try {
                Class.forName ("oracle.jdbc.driver.OracleDriver");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Survey.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                con = DriverManager.getConnection (
                        "jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g",
                        "sshres18", "hursyt");
            } catch (SQLException ex) {
                Logger.getLogger(Survey.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            StudentBean studentCheck = sdao.getStudentById(studentbean.getStudentid(),con);
            String checkSid = studentCheck.getStudentid();
            if(checkSid == ""){
                try {
                    sdao.save(studentbean,con);
                } catch (ClassNotFoundException ex) {
                    //Logger.getLogger(Survey.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            listreturn = sdao.retrieve(con);
            DataProcessor dp = new DataProcessor();
            String process = dp.calculation(datacalc);
            String pro[] = process.split(" ");
            
            double avg = Double.parseDouble(pro[0]);
            double sd = Double.parseDouble(pro[1]);
            
            //DataBean db = new DataBean();
            dtbn.setAvg(avg);
            dtbn.setSd(sd);
            
            if(avg > 90){
                fwdlink = "winner";
            }
            else{
                fwdlink = "simple";
            }
            try {
                con.close();
            } catch (SQLException ex) {
                
            }
           // return fwdlink;
        } catch (SQLException ex) {
            Logger.getLogger(Survey.class.getName()).log(Level.SEVERE, null, ex);
        }
        return fwdlink;
    }
    
    @Override
    public StudentBean getModel() {
        return studentbean;
    }
    
    public String getForm(){
        return "formPage";
    }
    
    public String getStudentById(){
        String url = "";
    try {
            Class.forName ("oracle.jdbc.driver.OracleDriver");
            //}
            //Connection con = ;
        
            Connection con = DriverManager.getConnection (
                    "jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g",
                    "sshres18", "hursyt");
            
            //String studentId = request.getParameter("sid");
            
            //StudentDAO sdao = new StudentDAO();
            studentbeanNew = sdao.getStudentById(StudentId,con);
          
           // HttpSession hs = request.getSession();
            //hs.setAttribute("studentinfo", studentResult);
            //request.setAttribute("stdinfo", studentResult);
            
            if(studentbeanNew.getStudentid()==""){
               // url = "/webpages/NoSuchStudentJSP.jsp";
                url = "missing";
            }
            else{
                //url = "/webpages/StudentJSP.jsp";
                url = "found";
            }
            con.close();
           // RequestDispatcher dispatcher = request.getRequestDispatcher(url);
          //  dispatcher.forward(request, response);
            
        } 
        catch (ClassNotFoundException ex) {
           // Logger.getLogger(mainServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (SQLException ex) {
            //Logger.getLogger(mainServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return url;
    }

}
