package tester;

import java.text.DecimalFormat;

/*
 * DataProcessor class to calculate the mean and standard deviation of the provided numbers. This is invoked
 * from the Servlet.
 */

/**
 *
 * @author Sewan Shrestha (sshres18)
 */
public class DataProcessor {
    public String calculation(String numbers){
        
    String[] num = numbers.split(",");
    int sum = 0;
    for (int i = 0; i < num.length; i++){
        sum += Integer.parseInt(num[i].trim());
    }
    double mean = (sum/num.length);
    DecimalFormat df = new DecimalFormat("#.##");
    
    //mean = Double.valueOf(df.format(mean));
    
    double[] deviations = new double[num.length];
  // Taking the deviation of mean from each numbers
  for(int i = 0; i < deviations.length; i++) {
   int numb = Integer.parseInt(num[i]);
   double absVal = Math.abs(numb - mean);
   //absVal = Double.valueOf(df.format(absVal));
   deviations[i] = (absVal * absVal) ; 
  }
 
  double totaldev = 0;
 
  for(int i =0; i< deviations.length; i++) {
   //squares[i] = deviations[i] * deviations[i];
      totaldev += deviations[i];
      //totaldev = Double.valueOf(df.format(totaldev));
  }
  double result = totaldev / ((num.length)-1);
  ///result = Double.valueOf(df.format(result));
  double sd = Math.sqrt(result);
  sd = Double.valueOf(df.format(sd));
  mean = Double.valueOf(df.format(mean));
  return mean+" "+sd;
 }
    
}
