package tester;
import java.sql.*;
/*
 * DAO object class to insert the survey information, retrieve the list of users and get the
 * student info by its id
 */

/**
 *
 * @author Sewan Shrestha (sshres18)
 */
public class StudentDAO{
    
        public void save(StudentBean sb, Connection con) throws SQLException, ClassNotFoundException {
            
            String insertstmt = "INSERT INTO STUDENT VALUES("
                      + "'"+sb.getStudentid()+"',"
                     + "'"+sb.getUsername()+"',"
                    + "'"+sb.getEmail()+"',"
                    + "'"+sb.getUrl()+"',"
                    + "'"+sb.getTel()+"',"
                    + "'"+sb.getStreetadd()+"',"
                    + "'"+sb.getCity()+"',"
                    + "'"+sb.getState()+"',"
                    +"'"+sb.getZip()+"',"
                    +"to_date('"+sb.getSurveydate()+"','yyyy-mm-dd'),"
                    + "'"+sb.getComments()+"',"
                    + "'"+sb.getGradmnth()+"',"
                    + "'"+sb.getGradyear()+"',"
                    + "'"+sb.getLike()+"',"
                    + "'"+sb.getInterest()+"',"
                    + "'"+sb.getReco()+"')";
            
            Statement statement = con.createStatement();
            statement.executeUpdate(insertstmt);
        }
        
        public String[] retrieve(Connection con) throws SQLException{
            String counttotal = "SELECT COUNT(*) students FROM STUDENT";
            Statement statement1 = con.createStatement();
            ResultSet rs1 = statement1.executeQuery (counttotal);
            String counter = "";
            while (rs1.next()){
              counter = rs1.getString ("students");   
            }
            String retrievedata = "SELECT * FROM STUDENT";
            Statement statement2 = con.createStatement();
            ResultSet rs2 = statement2.executeQuery (retrievedata);
            String[] list = new String[Integer.parseInt(counter)];
            int looper = 0;
            while (rs2.next()){
              list[looper] = rs2.getString("STUDENTID");  
              looper++;
            }
            
            return list;
        }
        
        public StudentBean getStudentById(String studentId,Connection con) throws SQLException{
            String findStudent = "SELECT * FROM STUDENT WHERE STUDENTID = '"+studentId+"'";
            Statement statement1 = con.createStatement();
            ResultSet rs1 = statement1.executeQuery (findStudent);
            StudentBean stb = new StudentBean();
            while (rs1.next()){
             stb.setStudentid(rs1.getString("STUDENTID"));
             stb.setUsername(rs1.getString("USERNAME"));
             stb.setEmail(rs1.getString("EMAIL"));
             stb.setUrl(rs1.getString("URL")); 
             stb.setTel(rs1.getString("TEL"));
             stb.setStreetadd(rs1.getString("STADDRESS"));
             stb.setCity(rs1.getString("CITY"));
             stb.setState(rs1.getString("STATE"));
             stb.setZip(rs1.getString("ZIP"));
             stb.setSurveydate(""+rs1.getDate("SURVEYDATE"));
             stb.setComments(rs1.getString("COMMENTS"));
             stb.setGradmnth(rs1.getString("GRADMNTH"));
             stb.setGradyear(rs1.getString("GRADYEAR"));
             stb.setLike(rs1.getString("LIKES"));
             stb.setInterest(rs1.getString("INTEREST")) ;
             stb.setReco(rs1.getString("RECO"));
            }
            return stb;
        }
        
}
