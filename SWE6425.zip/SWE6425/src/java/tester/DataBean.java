package tester;

/*
 * Databean class for accessor and mutator for the calculated mean and standard deviation.
 */

/**
 *
 * @author Sewan Shrestha (sshres18)
 */
public class DataBean {
    private double avg;
    private double sd;

    public double getAvg() {
        return avg;
    }

    public void setAvg(double avg) {
        this.avg = avg;
    }

    public double getSd() {
        return sd;
    }

    public void setSd(double sd) {
        this.sd = sd;
    }
    
}
