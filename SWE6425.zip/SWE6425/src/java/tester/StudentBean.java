package tester;

/*
 * Bean class for student and its accessors and mutators 
 */

/**
 *
 * @author Sewan Shrestha (sshres18)
 */
public class StudentBean {
        private String studentid = "";
        private String username = "";
        private String email    = "";
        private String url      = "";
        private String tel      = "n/a";
        private String streetadd= "";
        private String city     = "";
        private String state    = "";
        private String zip      = "";
        private String surveydate = "";
        private String comments = "";
        private String gradmnth = "";
        private String gradyear = "";
        private String like = "";
        private String interest = "";
        private String reco     = "";

    public StudentBean(){
        
    }
    
    public String getStudentid() {
        return studentid;
    }

    public void setStudentid(String studentid) {
        this.studentid = studentid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getStreetadd() {
        return streetadd;
    }

    public void setStreetadd(String streetadd) {
        this.streetadd = streetadd;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getSurveydate() {
        return surveydate;
    }

    public void setSurveydate(String surveydate) {
        this.surveydate = surveydate;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getGradmnth() {
        return gradmnth;
    }

    public void setGradmnth(String gradmnth) {
        this.gradmnth = gradmnth;
    }

    public String getGradyear() {
        return gradyear;
    }

    public void setGradyear(String gradyear) {
        this.gradyear = gradyear;
    }

    public String getLike() {
        return like;
    }

    public void setLike(String like) {
        this.like = like;
    }

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public String getReco() {
        return reco;
    }

    public void setReco(String reco) {
        this.reco = reco;
    }
        
}
