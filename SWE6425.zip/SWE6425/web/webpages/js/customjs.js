/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function greet() {
    var now = new Date();
    var hour = now.getHours();
    var name;
    var greetings;
    if (hour < 12) {
        greetings = "Good Afternoon";
    }
    else {
        hour = hour - 12;

        if (hour < 6) {
            greetings = "Good afternoon";
        }
        else {
            greetings = "Good Evening";
        }
    }
    if (document.cookie) {
        var cookieload = unescape(document.cookie);
        var cookieDelimit = cookieload.split("=");
        name = cookieDelimit[1];
    }
    else {
        name = window.prompt("Enter your name", "SWE642");
        document.cookie = "name=" + escape(name);
    }

    var changeuser = "<a href=\"javascript:changeuser()\">Not " + name + "?</a>";

    document.getElementById("greet").innerHTML = greetings + " " + name +
            ", welcome to Assignment#3 " + changeuser;

}

function changeuser() {
    document.cookie = "name=null;" + " expires=Thu, 01-Jan-95 00:00:01 GMT";
    location.reload();
}
/*
function calculate(){
    var max = 0;
    var numbers = document.getElementById("datacalc").value;
    var digit = numbers.split(",");
    for(var i= 0; i<digit.length; i++){
        
    }
}
*/
function validateZip(){
    var zipentered = document.getElementById("zip").value;
    document.getElementById("city").innerHTML = "";
    document.getElementById("state").innerHTML = "";
    var request = new XMLHttpRequest();
    var city = null; var state = null;
    request.open("GET", "webpages/zipcodes.json", true);
    request.onreadystatechange = function() {
        if ( request.readyState === 4 && request.status === 200 ) {
            var jsonobj = eval("("+request.responseText+")");
            for(var i=0;i<4;i++){
                
                if(jsonobj.zipcodes[i].zip === zipentered){
                    city = jsonobj.zipcodes[i].city;
                    state = jsonobj.zipcodes[i].state;
                }
               
            }
            if(city !== null && state !== null){
                document.getElementById("city").value = city;
                document.getElementById("state").value = state;
                document.getElementById("zipcodeerror").innerHTML = "";
            }
            else{
                document.getElementById("zipcodeerror").innerHTML = 
                        "<font color=\"red\">Invalid Zipcode</font>";
                document.getElementById("city").value = 
                        "Please enter Zipcode";
                document.getElementById("state").value = 
                        "Please enter Zipcode";
            }
              
        } 
    };
    request.send(null);
}

function calculate(){
    var values = document.getElementById("datacalc").value;
    document.getElementById("average").value = "";
    document.getElementById("maximum").value = "";
    var digits = values.split(",");
    var digitregex = /^[0-9]+$/;
    
    var sum = 0;
    var avg = 0;
    var max = 0;
    
    if(digits.length < 10){
        alert ("Please enter 10 valid numbers");
        return;
    }
    for(var i=0; i< digits.length; i++){
        var adigit = digits[i];
        if(!adigit.match(digitregex) || (parseInt(adigit)>100 || parseInt(adigit)<1)){
            alert("Please enter valid numbers between 0-100");
            return;
        }
        /*
        adigit = parseInt(adigit);
        sum += parseInt(adigit);
        if(adigit > max){
            max = adigit;
        }
     */   
    }
    /*
    avg = sum/digits.length;
    document.getElementById("average").value = avg;
    document.getElementById("maximum").value = max;
    */
}

function validationForm(){
    //var digitregex = /^[0-9]+$/;
    var alpharegex = /^[a-zA-Z ]+$/;
    var zipregex = /^([0-9]){5}?$/;
    var alphanumericregex = /^[a-zA-Z0-9 ]*$/;
    var emailregex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    var error ="";
     
    var studentid = document.getElementById("studentid").value;
    
    var username = document.getElementById("username").value;
    
    var address  = document.getElementById("streetadd").value;
    var zip  = document.getElementById("zip").value;
    var city  = document.getElementById("city").value;
    var state  = document.getElementById("state").value;
    
    var email = document.getElementById("email").value;
    
    var checklike = document.getElementsByName("like");
    var checks = 0;
    
    var checkinterest = document.getElementsByName("interest");
    var radios = 0;
     
    var values = document.getElementById("datacalc").value;
    var digits = values.split(",");
    var digitregex = /^[0-9]+$/;
    
    if(studentid == ""){
        error += "Please enter value for Student Id <br>"; 
    }
        
    if(!username.match(alpharegex)){
       error += "Please enter only alphabets in Username <br>"; 
       document.getElementById("username").value = "";
    }
    
    if(!city.match(alpharegex)){
       error += "Please enter only alphabets in City <br>"; 
       document.getElementById("city").value = "";
    }
    
    if(!state.match(alpharegex)){
       error += "Please enter only alphabets in State <br>"; 
       document.getElementById("state").value = "";
    }
    
    if(!address.match(alphanumericregex) || address==""){
        error += "Please enter only alphabets or numbers in Street Address <br>"; 
        document.getElementById("streetadd").value = "";
    }
    if(!zip.match(zipregex)){
        error += "Please enter valid 5 digit Zipcode <br>"; 
        document.getElementById("zip").value = "";
        
    }
    
    if(!email.match(emailregex)){
        error += "Please enter valid Email Address <br>"; 
        document.getElementById("email").value = "";
    }
    
    var chkedlike;
    for (var i = 0; i < checklike.length; i++) {
            if(checklike[i].checked === true) {
                checks += 1;
                chkedlike = i;
            }
    }
    
    if(checks < 2){
        error += "Please select atleast two check boxes in Like <br>"; 
        if(checks === 1){
            checklike[chkedlike].checked = false;
        }
    }
    
    for (var i = 0; i < checkinterest.length; i++) {
            if(checkinterest[i].checked === true) {
                radios += 1;
            }
    }
    
    if(radios !== 1 ){
        error += "Please select one radio in Interest <br>"; 
    }
    if(digits.length < 11){
        error += ("Please enter 10 valid numbers<br>");
    }
    for(var i=0; i< digits.length; i++){
        var adigit = digits[i];
        if(!adigit.match(digitregex) || (parseInt(adigit)>100 || parseInt(adigit)<1)){
            error += "Please enter valid numbers between 0-100<br>";
        }
    }
    if(error !== ""){
       
            $(document.createElement('div'))
                .attr({title: 'Errors Alert', 'class': 'alert'})
                .html(error)
                .dialog({
                    buttons: {OK: function(){$(this).dialog('close');}},
                    close: function(){$(this).remove();},
                    draggable: true,
                    modal: true,
                    resizable: false,
                    width: 'auto'
                });
        return false;
    }
    return true;
    
}
