-----------------------------------------------------------------------------

OVERVIEW:

SWE6425 is a Struts and Tiles project assignment for the class SWE642(Spring 2015). It includes a form to be submitted by students as survey for the CS department of George Mason University. In the project, the student enters their survey information. The form also has text box entry for 10 digits, which when calculate, if their mean is more than 90 it congratulates the student with two free movie tickets. If not it just thanks for the information and greets the data being saved message. Also, the student can click the links from the list of student ids and see their survey information.


CONTENTS:

   index.jsp  . . . . . . . . . . . . Link to go to the Survey Page
   stdSurvey.jsp . . . . . . . . . . .Survey form for the student
   SimpleAcknowledgement.jsp . . . . .Acknowledgement page for less than 91 mean
   WinnerAcknowledgement.jsp . . . . .Acknowledgement page for more than 90 mean
   README.txt   . . . . . . . . . . ..This file
   Survey.java . . . . . . . . . . . .Action page for Struts
   Databean.java .. . . . . . . . . . Java class file for Get and Set mean and 			    	      		      standard deviation
   DataProcessor.java  . . . . . . . .Java class business logic to calculate mean and 					      standard deviation
   StudentBean.java . . . . . . . . . Java class to Get and Set Student survey information
   StudentDAO.java . . . . . . . . . .Model class to save, retrieve data to and from 	 				      Database
   WEB-INF->lib. . . . . . . . . . . .Contains the JAR files for struts, tiles, database and JSTL
   WEB-INF->classes. . . . . . . . . .Contains struts.xml configuration file
   SWE6425->dist. . . . . . . . . . . Contains WAR files
   src->java->tester. . . . . . . . . Contains all the source files for Java
   web->webpages. . . . . . . . .. . .Contains all the web files

REQUIREMENTS:

The system, to run this project, requires Java, JRE, JDK, Apache Tomcat (preferably 7/8.0) installed. The system also will require IDE, Netbeans or Eclipse.

INSTALLATION:

Unpack the distribution. (If you are reading this file, you have probably
already done that.)

Using the WAR file:
 1. As you have unzipped the file, import the attached war file in the tomcat

Using the IDE:
 1. You download the assignment zip file
 2. Unzip the zip file using any unzip program, which must be done by now
 3. In netbeans, using File->Import Project->From Zip… 
    a. Link the zip file in Zip file entry box
    b. Folder name is where you want to import the file
    c. Press Import
 3. In Eclipse, using File->Import
    a. Select the file
    b. Click Import
 4. The new project will be in the Projects tab list

URL:
 http://localhost:8080/SWE6425/
 
This is the README file for SWE6425
Last updated for SWE6425 on 2015-05-04

COPYRIGHT and LICENSE:

SWE6425 is Copyright (C) 2015 Sewan Shrestha(sshres18)

This is free software is part of the SWE642 assignment for Spring 2015.
