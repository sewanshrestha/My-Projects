**************************************************
Readme.txt file of SWE645 Assignment 4
**************************************************
Author: Sewan Shrestha, sshres18, G00928061
**************************************************
The assignment folder contains the war file and the zipped file of the project itself. Please use the war file to use the project directly in your machine.

The project is also uploaded in AWS cloud system.
The URL for the S3 storage is 
 http://swe645-sshres18.s3-website-us-east-1.amazonaws.com/

 The page includes the link to the EC2 system where the survey application has been uploaded.
The URL for the EC2 is 
 http://ec2-52-87-171-144.compute-1.amazonaws.com/sshres18_HW4/
 