package com.sshres18.swe645;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.primefaces.json.JSONArray;
import org.primefaces.json.JSONException;
import org.primefaces.json.JSONObject;

/**
 * Restful Web service file for the survey form to get the City and State from according to the entered Zip code
 * @author sshres18
 *
 */


@Path("addresses")
public class AddressWS {
	
	@GET
	@Path("{zip}")
	@Produces("application/json")
	public AddressInfo getStateInfo(@PathParam("zip") String zipcode) throws JSONException, IOException{
		
		        String zipJson = "{\"zipcodes\":[{\"zip\": \"22312\",\"city\": \"Alexandria\",\"state\":\"VA\"},{\"zip\": \"22030\",\"city\": \"Fairfax\",\"state\":\"VA\"},{\"zip\": \"22301\",\"city\": \"Tysons Corner\",\"state\":\"MD\"},{\"zip\": \"20148\",\"city\": \"Ashburn\",\"state\":\"VA\"}]}";
				//\HelperClass hclass = new HelperClass();
				InputStream ist = HelperClass.class.getResourceAsStream("/Users/blaugrana/Documents/workspace_ii/SWE645HW3/src/com/sshres18/swe645/zip.txt");
				String AbsolutePath = new File("").getAbsolutePath();
				System.out.println(AbsolutePath+"----");
				//String zipJson = hclass.getAddressesForJSON();
				JSONObject job = new JSONObject(zipJson);
				JSONArray  jarr = job.getJSONArray("zipcodes");
				AddressInfo ai = new AddressInfo();
				for(int i = 0; i<jarr.length(); i++){
					String jsonZip = jarr.getJSONObject(i).getString("zip");
					if(jsonZip.equals(zipcode)){
						ai.setCity(jarr.getJSONObject(i).getString("city"));
						ai.setState(jarr.getJSONObject(i).getString("state"));
					}
				}
				return  ai;	
	}
	
}
