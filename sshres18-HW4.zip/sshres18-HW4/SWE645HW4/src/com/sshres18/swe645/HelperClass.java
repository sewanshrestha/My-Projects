package com.sshres18.swe645;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

/**
 * This helper class isnt implemented. It will be used for reading the zip codes from the file
 * @author sshres18
 *
 */

public class HelperClass {

	//Test method to read zip from json file - incomplete
	public String getAddressesForJSON() throws IOException {

				//ExternalContext servletContext = FacesContext.getCurrentInstance().getExternalContext();
				//InputStream zipIS = servletContext.getResourceAsStream("zipInfo/zip.json");
				//String fileName = "zipjson.json";
				String fileName = "/src/com/sshres18/swe645/zip.txt";
				String AbsolutePath = new File("").getAbsolutePath();
				File file = new File(fileName);
				/*
				System.out.println(this.getClass().getResource("/").getPath()+"-------");
				*/
				BufferedReader br = null;
				StringBuilder sb = new StringBuilder();
				FileReader fileReader =  new FileReader(fileName);
				String line;
				try {

					br = new BufferedReader(fileReader);
					while ((line = br.readLine()) != null) {
						sb.append(line);
					}

				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					if (br != null) {
						try {
							br.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
				return sb.toString();
			}
}
