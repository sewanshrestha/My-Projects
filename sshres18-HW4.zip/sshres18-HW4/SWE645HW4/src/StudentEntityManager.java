import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
/**
 * Student entity manager  to interact with the database/file for CRUD. 
 * @author sshres18
 *
 */

public class StudentEntityManager {
	private static EntityManager em;
	public StudentEntityManager(){
		//System.out.println("emcons");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("SWE645HW4");
		em = emf.createEntityManager();
	}
	
	public void addSurvey(Student student){
		em.getTransaction().begin();
		em.persist(student);
		em.getTransaction().commit();
	   // em.close();
	}
	
	public void deleteSurvey(Student stud){
		
		em.getTransaction().begin();
		Student toRemove = em.merge(stud);  
	    em.remove(toRemove);
		em.getTransaction().commit();
		//em.close();
		
	}
	
	public ArrayList<Student> getAllSurveys(){
		//ArrayList<Student> student = new ArrayList<Student>();
		Query q = em.createQuery("select s from Student s");
		return (ArrayList<Student>) q.getResultList();
		
	}
	
	public static ArrayList<Student> getSearchResult(String fName,
	String lName,
	String city,
	String state){
		
		//ArrayList<Student> student = new ArrayList<Student>();
		em.getTransaction().begin();
		Query q = em.createQuery("select s from Student s where lower(s.firstName) like '"+fName.toLowerCase()+"' or lower(s.lastName)='"+lName.toLowerCase()+
								 "' or lower(s.city)='"+city.toLowerCase()+"' or lower(s.state)='"+state.toLowerCase()+"'");
		//em.close();
		return (ArrayList<Student>) q.getResultList();
		
	}
	
}
