import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.sql.*;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.io.FileOutputStream;

//import javax.servlet.ServletContext;
/**
 * Student service model layer to interact with the database/file to store and get the list. It also calculates the mean and
 * standard deviation of range
 * @author sshres18
 *
 */

public class StudentService {
	/*
	public String saveStudent(Student sb) throws SQLException, ClassNotFoundException {
		
        Connection con = null;
        try {
            Class.forName ("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException ex) {
           
        }
        try {
            con = DriverManager.getConnection (
                    "jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g",
                    "sshres18", "esoals");
        } catch (SQLException ex) {
            
        }
     	
       
        String liker = sb.getCSVLikes();
        
        String insertstmt = "INSERT INTO STUDENTSWE VALUES("
                  + "'"+sb.getFirstName()+"',"
                 + "'"+sb.getLastName()+"',"
                + "'"+sb.getEmail()+"',"
                + "'"+sb.getUrl()+"',"
                + "'"+sb.getTelephoneNumber()+"',"
                + "'"+sb.getStreetAddress()+"',"
                + "'"+sb.getCity()+"',"
                + "'"+sb.getState()+"',"
                +"'"+sb.getZip()+"',"
                +"to_date('"+sb.getDateOfSurvey()+"','mm-dd-yyyy'),"
                + "'"+sb.getComments()+"',"
                + "'"+liker+"',"
                + "'"+sb.getInterests()+"',"
                + "'"+sb.getRecommendation()+"')";
        System.out.println(insertstmt);
        Statement statement = con.createStatement();
        statement.executeUpdate(insertstmt);
        return "index";
    }
    
    public List<Student> retrieve() throws SQLException{
    	List<Student> list = new ArrayList<Student>();
    	Connection con = null;
    	PreparedStatement ps = null;
    	ResultSet rs = null;
        try {
            Class.forName ("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException ex) {
           
        }
        try {
            con = DriverManager.getConnection (
                    "jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g",
                    "sshres18", "esoals");
        } catch (SQLException ex) {
            
        }
        
        
        String sql = "SELECT * FROM STUDENTSWE";
        ps= con.prepareStatement(sql); 
        rs= ps.executeQuery(); 
        while (rs.next())
        {
        Student st = new Student();
        st.setFirstName(rs.getString("FIRSTNAME"));
        st.setLastName(rs.getString("LASTNAME"));
        st.setEmail(rs.getString("EMAIL"));
        st.setUrl(rs.getString("URL"));
        st.setTelephoneNumber(rs.getString("TELEPHONENUMBER"));
        st.setStreetAddress(rs.getString("STREETADDRESS"));
        st.setCity(rs.getString("CITY"));
        st.setState(rs.getString("STATE"));
        st.setZip(rs.getString("ZIP"));
        st.setComments(rs.getString("COMMENTS"));
        String[] tokens = rs.getString("LIKES").split(",", -1);
        st.setLikes(tokens);
        st.setInterests(rs.getString("INTERESTS"));
        st.setRecommendation(rs.getString("RECOMMENDATION"));
       // st.setDateOfSurvey(rs.getDate("DATEOFSURVEY"));
       // st.setDateOfStart(rs.getDate("DATEOFSTART"));
        list.add(st);
        } 
        return list;
    }
	
*/

    
    
    public void writeFile(Student s) throws IOException{
    	Writer writer = new FileWriter("/opt/bitnami/apache-tomcat/webapps/sweFile/output.txt",true);
    	try
		{
			writer.write(s+System.getProperty("line.separator"));
		}
		finally
		{
			writer.close();
		}
    }
	
    public void readFile(List<Student> students) throws IOException, ParseException
	{
    	try(BufferedReader br = new BufferedReader(new FileReader("/opt/bitnami/apache-tomcat/webapps/sweFile/output.txt")))
		{
			String current=br.readLine();
			
			while(current!=null)
			{
				String disp[] = current.split("\\::");
				Student newStudent = new Student();
				newStudent.setFirstName(disp[0]);
				newStudent.setLastName(disp[1]);
				newStudent.setStreetAddress(disp[2]);
				newStudent.setCity(disp[3]);
				newStudent.setState(disp[4]);
				newStudent.setZip(disp[5]);
				newStudent.setTelephoneNumber(disp[6]);
				newStudent.setEmail(disp[7]);
				DateFormat dfm = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
				newStudent.setDateOfSurvey(dfm.parse(disp[8]));
				//newStudent.setDateOfStart(dfm.parse(disp[]));
				newStudent.setInterests(disp[9]);
				newStudent.setRecommendation(disp[10]);
				//newStudent.set(disp[11]);
				newStudent.setComments(disp[12]);
				newStudent.setUrl(disp[13]);
				//newStudent.setLikes(disp[14]);
				String[] tokens = disp[14].split(",", -1);
		        newStudent.setLikes(tokens);
		       // DateFormat dfm = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
				newStudent.setDateOfStart(dfm.parse(disp[15]));
		        students.add(newStudent);
			
				current=br.readLine();
			}
			
		}
		
	}
    
	public String calculateMean(String numbers){
		String[] num = numbers.split(",");
	    int sum = 0;
	    for (int i = 0; i < num.length; i++){
	        sum += Integer.parseInt(num[i].trim());
	    }
	    double mean = (sum/num.length);
	    DecimalFormat df = new DecimalFormat("#.##");
	    
	    //mean = Double.valueOf(df.format(mean));
	    
	    double[] deviations = new double[num.length];
	  // Taking the deviation of mean from each numbers
	  for(int i = 0; i < deviations.length; i++) {
	   int numb = Integer.parseInt(num[i]);
	   double absVal = Math.abs(numb - mean);
	   //absVal = Double.valueOf(df.format(absVal));
	   deviations[i] = (absVal * absVal) ; 
	  }
	 
	  double totaldev = 0;
	 
	  for(int i =0; i< deviations.length; i++) {
	   //squares[i] = deviations[i] * deviations[i];
	      totaldev += deviations[i];
	      //totaldev = Double.valueOf(df.format(totaldev));
	  }
	  double result = totaldev / ((num.length)-1);
	  ///result = Double.valueOf(df.format(result));
	  double sd = Math.sqrt(result);
	  sd = Double.valueOf(df.format(sd));
	  mean = Double.valueOf(df.format(mean));
	  return mean+" "+sd;
	}
	
}
