//import java.sql.SQLException;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.validator.ValidatorException;

import org.primefaces.json.JSONException;
import org.primefaces.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

/**
 * Manager bean for the project which takes the requests from the JSFs and sends them to Service file to save,
 * calculate mean and standard deviation and get the list of surveys. The City and State are populated from the entered Zip code using web service. 
 * The options for recommendations are also made autocomplete
 * @author sshres18
 *
 */

@ManagedBean
public class Studentbean {
	
	
	private Student student = new Student();
	private WinningResult wr = new WinningResult();
	//private List<Student> students = new ArrayList<Student>();
	private String surveyList;
	
	public String getSurveyList(){
		return this.surveyList;
	}
	
	public void setSurveyLisy(String surveyList){
		this.surveyList = surveyList;
	}
	public WinningResult getWr() {
		return wr;
	}

	public void setWr(WinningResult wr) {
		this.wr = wr;
	}

	public Studentbean(){
		
	}
	
	public Student getStudent() {
		return student;
	}
    /*
	public void setStudent(Student student){
		this.student = student;
	}
	*/
	
	/* fordb
	public String processSave() throws ClassNotFoundException, SQLException{
		StudentService studentService = new StudentService();
	    String saveStatus = studentService.saveStudent(student);
		String calculation = studentService.calculateMean(student.getRaffle());
		
		String pro[] = calculation.split(" ");
        
        double avg = Double.parseDouble(pro[0]);
        double sd = Double.parseDouble(pro[1]);
        
        wr.setMean(avg);
        wr.setStandarddeviation(sd);
        
        if(avg > 90){
        	return "WinnerAcknowledgement";
        }
        
        return "SimpleAcknowledgement";
		
	}
	*/
	
	
	
	public String processSave() throws IOException{
		StudentService studentService = new StudentService();
		//String saveStatus = studentService.saveStudent(student);
		studentService.writeFile(student);
		//System.out.println(""student.getDateOfStart());
		String calculation = studentService.calculateMean(student.getRaffle());
		
		String pro[] = calculation.split(" ");
	    
	    double avg = Double.parseDouble(pro[0]);
	    double sd = Double.parseDouble(pro[1]);
	    
	    wr.setMean(avg);
	    wr.setStandarddeviation(sd);
	    //students.add(student);
	    if(avg > 90){
	    	return "winner";
	    }
	    
	    return "simple";
	    
	}
	
	public void datecheck(AjaxBehaviorEvent a) throws ValidatorException{
		FacesContext fc = FacesContext.getCurrentInstance();
		Date tempSurveyDate = (Date)student.getDateOfSurvey();
		Date tempStartDate  = (Date)student.getDateOfStart();
		System.out.println(tempSurveyDate+"--"+tempStartDate);
		if(tempStartDate.before(tempSurveyDate)){
			fc.addMessage(null, new FacesMessage("Start date is before the survey date!"));
		}
	}
	
	public void updateaddress() throws JSONException{
		FacesContext fc = FacesContext.getCurrentInstance();
		String tempZip = "";
		
	//	HelperClass hc = new HelperClass();
	//	String zipJson = hc.getAddressesForJSON();
		
		try{
			 tempZip = student.getZip();
		}
		catch(Exception e){
			fc.addMessage(null, new FacesMessage("Zipcode not digits!"));
		}
		Client client = Client.create();
		WebResource wrs = client.resource("http://ec2-52-87-171-144.compute-1.amazonaws.com/SWE645HW3/webresources/addresses/"+tempZip);
		ClientResponse resp = wrs.accept("application/json").get(ClientResponse.class);
		String tempZipjson = resp.getEntity(String.class);
		
		/*
		String tempAddress = aws.getStateInfo(tempZip);
		if(tempAddress.equals("")){
			fc.addMessage(null, new FacesMessage("Zipcode not found!"));
		}
		else{
			 String[] tempVal =  tempAddress.split("::", 2);
		     student.setCity(tempVal[0]);
		     student.setState(tempVal[1]);
		}
		*/
		
		JSONObject job = new JSONObject(tempZipjson);
		String tempState="", tempCity="";
		try{
			 tempState = job.getString("state");
			 tempCity  = job.getString("city");
		}
		catch(JSONException j){
			fc.addMessage(null, new FacesMessage("Zipcode not found!"));
		}
		if(tempState.equals("null") || tempCity.equals("null")){
			fc.addMessage(null, new FacesMessage("Zipcode not found!"));	
		}
		else{
			student.setCity(tempCity);
			student.setState(tempState);
		}
	}
	
	
	

	/*
	public List<Student> getStudentList() throws SQLException{
		StudentService studentService = new StudentService();
		return studentService.retrieve();
	}
	*/
	
	public List<Student> getSurveyListing() throws IOException, ParseException{
		List<Student> students = new ArrayList<Student>();
		StudentService srv = new StudentService();
		srv.readFile(students);
		return students;
		
	}
	
	private static final String options = "Likely,Unlikely,Very Likely";
	private static final String[] toCheck = options.split(",");
	
	public List<String> recommendOption(String entry){
		List<String>matchFound = new ArrayList<String>();
		for(String value : toCheck){
			if(value.toLowerCase().startsWith(entry.toLowerCase())){
				matchFound.add(value);
			}
		}
		
		return matchFound;
	}
	
/*
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	*/
}
