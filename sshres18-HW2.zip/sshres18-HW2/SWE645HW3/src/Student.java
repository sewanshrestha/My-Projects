import java.util.Date;

/**
 * Student data object(POJO) to store the individual attributes of the Student object
 * @author sshres18
 *
 */
public class Student {
	private String firstName, lastName, streetAddress, city, state, zip, telephoneNumber, 
    email, interests, recommendation, raffle, comments, url;

	//private String dateOfSurvey, dateOfStart;
	
	private Date dateOfSurvey, dateOfStart;
	
	private String[] likes;
	
	public Student(){
		
	}
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDateOfSurvey() {
		return dateOfSurvey;
	}

	public void setDateOfSurvey(Date dateOfSurvey)  {
		this.dateOfSurvey = dateOfSurvey;
		
	}
	
	public Date getDateOfStart() {
		return dateOfStart;
	}

	public void setDateOfStart(Date dateOfStart)  {
		this.dateOfStart = dateOfStart;
	}
/*
	public String getDateOfSurvey() {
		return dateOfSurvey;
	}

	public void setDateOfSurvey(String dateOfSurvey) {
		this.dateOfSurvey = dateOfSurvey;
	}
	
	public String getDateOfStart() {
		return dateOfStart;
	}

	public void setDateOfStart(String dateOfStart) {
		this.dateOfStart = dateOfStart;
	}
*/
	
	public String getInterests() {
		return interests;
	}

	public void setInterests(String interests) {
		this.interests = interests;
	}

	public String getRecommendation() {
		return recommendation;
	}

	public void setRecommendation(String recommendation) {
		this.recommendation = recommendation;
	}

	public String getRaffle() {
		return raffle;
	}

	public void setRaffle(String raffle) {
		this.raffle = raffle;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String[] getLikes() {
		return likes;
	}

	public void setLikes(String[] likes) {
		this.likes = likes;
	}
	
	public String getCSVLikes(){
		StringBuilder nameBuilder = new StringBuilder();

        for (String n : this.getLikes()) {
            nameBuilder.append(n.replace("", "")).append(",");
            
        }

        nameBuilder.deleteCharAt(nameBuilder.length() - 1);

        return nameBuilder.toString();
	}
	
	public String toString(){
		String result = getFirstName()+"::"+getLastName()+"::"+
						getStreetAddress()+"::"+getCity()+"::"+getState()+"::"+getZip()+"::"+
						getTelephoneNumber()+"::"+getEmail()+"::"+getDateOfSurvey()+"::"+
						getInterests()+"::"+getRecommendation()+"::"+getRaffle()+"::"+getComments()
						+"::"+getUrl()+"::"+getCSVLikes()+"::"+getDateOfStart();
		return result;
	}
}
